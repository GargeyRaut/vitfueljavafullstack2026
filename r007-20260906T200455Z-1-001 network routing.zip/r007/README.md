# Network Routing Simulator — Phase 1 + Phase 2

Two standalone Maven projects, based on the Network Routing Simulator
system design doc:

- **`phase1-network-routing-simulator/`** — core domain model, two
  routing algorithms (Dijkstra, Bellman-Ford), the discrete-event
  simulation engine, and an in-memory REST API. Start here to read or
  run the simplest version.

- **`phase2-network-routing-simulator/`** — everything in Phase 1,
  plus JPA persistence (H2/PostgreSQL), durable run history with
  pagination, a live WebSocket event stream, a third routing algorithm
  (distance-vector), OpenAPI/Swagger docs, Docker Compose, and unit
  tests. This is the one to run if you want the fuller feature set.

Each folder is self-contained (its own `pom.xml`) and builds
independently — see the `README.md` inside each for how to run it and
what it adds.
