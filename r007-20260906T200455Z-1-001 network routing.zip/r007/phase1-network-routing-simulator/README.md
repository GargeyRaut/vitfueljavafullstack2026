# Network Routing Simulator — Phase 1

Core domain model, pluggable routing algorithms, and a discrete-event
simulation engine exposed over a plain REST API, all held in memory.

## What's in here

- **Domain**: `Router`, `Link`, `Packet`, `NetworkTopology`, `RoutingTable`
- **Routing algorithms** (Strategy pattern): Dijkstra, Bellman-Ford
- **Simulation engine**: hop-by-hop packet forwarding over a virtual
  clock, with latency/bandwidth/jitter/loss modeled per link
- **REST API**: create topologies, add routers/links, fault-inject
  router/link status, trigger a simulation run and fetch its result
- **Storage**: in-memory only — nothing survives a restart

## Run it

```
mvn spring-boot:run
```

## Try it

```
POST /api/topologies                       {"name":"lab-net"}
POST /api/topologies/{id}/routers           {"label":"R1"}
POST /api/topologies/{id}/links             {"sourceId":"...","targetId":"...","bandwidthMbps":100,"latencyMs":5,"reliabilityPct":99,"bidirectional":true}
PATCH /api/topologies/{id}/routers/{rid}/status  {"status":"DOWN"}
PATCH /api/topologies/{id}/links/{lid}/status    {"status":"DOWN"}
POST /api/simulations/run                   {"topologyId":"...","sourceRouterId":"...","destRouterId":"...","algorithm":"dijkstra"}
GET  /api/simulations/{runId}
```

## What Phase 2 adds

See `../phase2-network-routing-simulator/README.md` — persistence,
run history, live WebSocket events, a third routing algorithm, and
API docs.
