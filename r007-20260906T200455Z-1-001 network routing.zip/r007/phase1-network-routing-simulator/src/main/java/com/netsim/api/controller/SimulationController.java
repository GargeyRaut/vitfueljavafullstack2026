package com.netsim.api.controller;

import com.netsim.api.dto.Dtos.SimulationResultDTO;
import com.netsim.api.dto.Dtos.SimulationRunRequestDTO;
import com.netsim.api.service.SimulationOrchestratorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/simulations")
public class SimulationController {

    private final SimulationOrchestratorService orchestrator;

    public SimulationController(SimulationOrchestratorService orchestrator) {
        this.orchestrator = orchestrator;
    }

    @PostMapping("/run")
    @ResponseStatus(HttpStatus.OK)
    public SimulationResultDTO run(@Valid @RequestBody SimulationRunRequestDTO request) {
        return orchestrator.runSimulation(request);
    }

    @GetMapping("/{runId}")
    public SimulationResultDTO get(@PathVariable String runId) {
        return orchestrator.getRun(runId);
    }
}
