package com.netsim.api.controller;

import com.netsim.api.dto.Dtos.*;
import com.netsim.api.service.TopologyRepository;
import com.netsim.domain.Interface;
import com.netsim.domain.Link;
import com.netsim.domain.NetworkTopology;
import com.netsim.domain.Router;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/topologies")
public class TopologyController {

    private final TopologyRepository topologyRepository;

    public TopologyController(TopologyRepository topologyRepository) {
        this.topologyRepository = topologyRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TopologyDTO create(@Valid @RequestBody CreateTopologyRequest request) {
        NetworkTopology topology = topologyRepository.create(request.name());
        return toDto(topology);
    }

    @GetMapping("/{id}")
    public TopologyDTO get(@PathVariable String id) {
        return toDto(topologyRepository.get(id));
    }

    @PostMapping("/{id}/routers")
    @ResponseStatus(HttpStatus.CREATED)
    public RouterDTO addRouter(@PathVariable String id, @Valid @RequestBody AddRouterRequest request) {
        NetworkTopology topology = topologyRepository.get(id);
        String routerId = "R-" + UUID.randomUUID().toString().substring(0, 6);
        Router router = topology.addRouter(new Router(routerId, request.label()));
        return toDto(router);
    }

    @PostMapping("/{id}/links")
    @ResponseStatus(HttpStatus.CREATED)
    public LinkDTO addLink(@PathVariable String id, @Valid @RequestBody AddLinkRequest request) {
        NetworkTopology topology = topologyRepository.get(id);
        topology.requireRouter(request.sourceId());
        topology.requireRouter(request.targetId());
        String linkId = "L-" + UUID.randomUUID().toString().substring(0, 6);
        Link link = topology.addLink(new Link(linkId, request.sourceId(), request.targetId(),
                request.bandwidthMbps(), request.latencyMs(), request.reliabilityPct(), request.bidirectional()));
        return toDto(link);
    }

    private TopologyDTO toDto(NetworkTopology topology) {
        return new TopologyDTO(topology.getId(), topology.getName(),
                topology.getRouters().size(), topology.getLinks().size());
    }

    private RouterDTO toDto(Router router) {
        return new RouterDTO(router.getId(), router.getLabel(), router.getStatus().name(),
                router.getInterfaces().values().stream().map(Interface::name).toList());
    }

    private LinkDTO toDto(Link link) {
        return new LinkDTO(link.getId(), link.getSourceRouterId(), link.getTargetRouterId(),
                link.getBandwidthMbps(), link.getLatencyMs(), link.getReliabilityPct(), link.getStatus().name());
    }
}
