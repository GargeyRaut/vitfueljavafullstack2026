package com.netsim.api.service;

import com.netsim.api.dto.Dtos.SimulationResultDTO;
import com.netsim.api.dto.Dtos.SimulationRunRequestDTO;
import com.netsim.domain.NetworkTopology;
import com.netsim.engine.SimulationEngine;
import com.netsim.engine.SimulationRequest;
import com.netsim.engine.SimulationResult;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Coordinates a simulation run: resolves the topology, drives the
 * {@link SimulationEngine}, and keeps a run-history cache so completed
 * runs can be fetched back by id (stand-in for the persisted
 * simulation_run / simulation_hop tables in section 7).
 */
@Service
public class SimulationOrchestratorService {

    private final TopologyRepository topologyRepository;
    private final SimulationEngine simulationEngine;
    private final Map<String, SimulationResult> runHistory = new ConcurrentHashMap<>();

    public SimulationOrchestratorService(TopologyRepository topologyRepository, SimulationEngine simulationEngine) {
        this.topologyRepository = topologyRepository;
        this.simulationEngine = simulationEngine;
    }

    public SimulationResultDTO runSimulation(SimulationRunRequestDTO request) {
        NetworkTopology topology = topologyRepository.get(request.topologyId());
        SimulationRequest engineRequest = SimulationRequest.of(
                request.topologyId(), request.sourceRouterId(), request.destRouterId(), request.algorithm());

        SimulationResult result = simulationEngine.run(topology, engineRequest);
        runHistory.put(result.runId(), result);
        return toDto(result);
    }

    public SimulationResultDTO getRun(String runId) {
        SimulationResult result = runHistory.get(runId);
        if (result == null) {
            throw new java.util.NoSuchElementException("Unknown simulation run: " + runId);
        }
        return toDto(result);
    }

    private SimulationResultDTO toDto(SimulationResult result) {
        return new SimulationResultDTO(result.runId(), result.path(), result.totalLatencyMs(),
                result.hopCount(), result.packetLossPct(), result.status());
    }
}
