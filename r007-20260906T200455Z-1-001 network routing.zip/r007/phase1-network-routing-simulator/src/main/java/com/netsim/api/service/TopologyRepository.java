package com.netsim.api.service;

import com.netsim.domain.NetworkTopology;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory topology store. Stands in for the Spring Data JPA
 * repository layer described in the design doc (section 7); swap for a
 * real {@code TopologyJpaRepository} + mapper without touching callers,
 * since they only depend on this interface's method signatures.
 */
@Repository
public class TopologyRepository {

    private final Map<String, NetworkTopology> topologies = new ConcurrentHashMap<>();

    public NetworkTopology create(String name) {
        String id = "topo-" + UUID.randomUUID().toString().substring(0, 6);
        NetworkTopology topology = new NetworkTopology(id, name);
        topologies.put(id, topology);
        return topology;
    }

    public NetworkTopology get(String id) {
        NetworkTopology topology = topologies.get(id);
        if (topology == null) {
            throw new NoSuchElementException("Unknown topology: " + id);
        }
        return topology;
    }

    public Iterable<NetworkTopology> all() {
        return topologies.values();
    }
}
