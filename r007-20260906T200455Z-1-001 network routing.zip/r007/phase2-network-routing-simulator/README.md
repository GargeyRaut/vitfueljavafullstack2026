# Network Routing Simulator — Phase 2

Builds on Phase 1's domain model and simulation engine, adding
persistence, run history, live streaming, a third routing algorithm,
and API docs.

## New in Phase 2

- **Persistence (Spring Data JPA)** — `topology`, `router`, `link`,
  `simulation_run`, `simulation_hop`, `simulation_metric` tables.
  H2 in-memory by default for local dev; PostgreSQL via
  `docker-compose.yml` for a closer-to-prod setup. The live topology
  graph still lives in memory during a run (per the original design's
  section 7 note) — mutations are checkpointed through to the DB as
  they happen, and each simulation's hop trace + metrics are persisted
  once the run finishes.
- **Run history** — `GET /api/simulations?topologyId=&page=&size=`
  returns a paginated list of past runs for a topology;
  `GET /api/simulations/{runId}` now reads from the DB (hop trace +
  metrics) instead of an in-memory cache, so it survives restarts.
- **Live WebSocket event stream** — STOMP over SockJS at
  `/ws/simulations`; subscribe to `/topic/simulations/{runId}` to see
  `HOP_REACHED` / `PACKET_DROPPED` / `LINK_DOWN` / `ROUTE_RECOMPUTED` /
  `DELIVERED` events as a run happens, independent of the persisted
  trace.
- **Distance-vector routing algorithm** — a third `RoutingAlgorithm`
  (`"distance-vector"`), modeled as neighbor-to-neighbor vector
  exchanges converging over several rounds, alongside Dijkstra and
  Bellman-Ford. Select it the same way: `"algorithm":"distance-vector"`
  in a simulation-run request.
- **OpenAPI / Swagger UI** — `GET /v3/api-docs`,
  `GET /swagger-ui.html`.
- **Docker Compose** — app + PostgreSQL, matching the original design
  doc's deployment architecture (section 11).
- **Unit tests** — routing-algorithm correctness on a small diamond
  topology, including a fault-injection reroute case.

## Run it

Local dev (H2, in-memory DB):
```
mvn spring-boot:run
```

With PostgreSQL via Docker:
```
docker compose up --build
```

## New endpoints on top of Phase 1

```
GET  /api/simulations?topologyId=topo-42&page=0&size=20
WS   /ws/simulations   (STOMP, subscribe to /topic/simulations/{runId})
GET  /swagger-ui.html
GET  /v3/api-docs
```

Everything from Phase 1 (`/api/topologies`, `/api/topologies/{id}/routers`,
`/api/topologies/{id}/links`, fault-injection PATCH endpoints,
`POST /api/simulations/run`) still works the same way.

## Not yet implemented

Kafka event fan-out, MapStruct-generated mappers (a hand-written
mapper is used instead), multi-tenant workspaces, and the other
"Future Enhancements" items from design doc section 12.
