package com.netsim.api.controller;

import com.netsim.api.dto.Dtos.SimulationResultDTO;
import com.netsim.api.dto.Dtos.SimulationRunRequestDTO;
import com.netsim.api.dto.Dtos.SimulationRunSummaryDTO;
import com.netsim.api.service.SimulationOrchestratorService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/simulations")
public class SimulationController {

    private final SimulationOrchestratorService orchestrator;

    public SimulationController(SimulationOrchestratorService orchestrator) {
        this.orchestrator = orchestrator;
    }

    @PostMapping("/run")
    @ResponseStatus(HttpStatus.OK)
    public SimulationResultDTO run(@Valid @RequestBody SimulationRunRequestDTO request) {
        return orchestrator.runSimulation(request);
    }

    @GetMapping("/{runId}")
    public SimulationResultDTO get(@PathVariable String runId) {
        return orchestrator.getRun(runId);
    }

    /** Phase 2: paginated run-history listing for a topology (design doc section 8). */
    @GetMapping
    public Page<SimulationRunSummaryDTO> list(@RequestParam String topologyId,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        return orchestrator.getRunHistory(topologyId, pageable);
    }
}
