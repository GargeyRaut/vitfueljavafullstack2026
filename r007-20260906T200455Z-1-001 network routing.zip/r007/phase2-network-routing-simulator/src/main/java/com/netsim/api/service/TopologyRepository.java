package com.netsim.api.service;

import com.netsim.domain.Link;
import com.netsim.domain.NetworkTopology;
import com.netsim.domain.Router;
import com.netsim.persistence.mapper.DomainEntityMapper;
import com.netsim.persistence.repository.LinkJpaRepository;
import com.netsim.persistence.repository.RouterJpaRepository;
import com.netsim.persistence.repository.TopologyJpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The live network graph used during an active simulation is kept in
 * memory (design doc section 7: "only checkpointed/persisted at run
 * boundaries"). Phase 2 adds that checkpoint: every mutation is also
 * written through to the {@code topology}/{@code router}/{@code link}
 * tables via Spring Data JPA, so topology definitions survive restarts
 * and can back an audit trail, while reads of the active graph stay
 * fast and framework-free.
 */
@Repository
public class TopologyRepository {

    private final Map<String, NetworkTopology> topologies = new ConcurrentHashMap<>();

    private final TopologyJpaRepository topologyJpaRepository;
    private final RouterJpaRepository routerJpaRepository;
    private final LinkJpaRepository linkJpaRepository;
    private final DomainEntityMapper mapper;

    public TopologyRepository(TopologyJpaRepository topologyJpaRepository,
                               RouterJpaRepository routerJpaRepository,
                               LinkJpaRepository linkJpaRepository,
                               DomainEntityMapper mapper) {
        this.topologyJpaRepository = topologyJpaRepository;
        this.routerJpaRepository = routerJpaRepository;
        this.linkJpaRepository = linkJpaRepository;
        this.mapper = mapper;
    }

    @Transactional
    public NetworkTopology create(String name) {
        String id = "topo-" + UUID.randomUUID().toString().substring(0, 6);
        NetworkTopology topology = new NetworkTopology(id, name);
        topologies.put(id, topology);
        topologyJpaRepository.save(mapper.toEntity(topology));
        return topology;
    }

    public NetworkTopology get(String id) {
        NetworkTopology topology = topologies.get(id);
        if (topology == null) {
            throw new NoSuchElementException("Unknown topology: " + id);
        }
        return topology;
    }

    public Iterable<NetworkTopology> all() {
        return topologies.values();
    }

    /** Adds a router to the live graph and checkpoints it to the database. */
    @Transactional
    public Router addRouter(NetworkTopology topology, Router router) {
        topology.addRouter(router);
        routerJpaRepository.save(mapper.toEntity(router, topology.getId()));
        return router;
    }

    /** Adds a link to the live graph and checkpoints it to the database. */
    @Transactional
    public Link addLink(NetworkTopology topology, Link link) {
        topology.addLink(link);
        linkJpaRepository.save(mapper.toEntity(link, topology.getId()));
        return link;
    }

    /** Re-checkpoints a router's mutable status (e.g. after fault injection). */
    @Transactional
    public void checkpointRouterStatus(Router router) {
        routerJpaRepository.findById(router.getId()).ifPresent(entity -> {
            entity.setStatus(router.getStatus().name());
            routerJpaRepository.save(entity);
        });
    }

    /** Re-checkpoints a link's mutable status (e.g. after fault injection). */
    @Transactional
    public void checkpointLinkStatus(Link link) {
        linkJpaRepository.findById(link.getId()).ifPresent(entity -> {
            entity.setStatus(link.getStatus().name());
            linkJpaRepository.save(entity);
        });
    }
}
