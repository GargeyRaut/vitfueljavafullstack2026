# Network Routing Simulator — Phase 3

Everything from Phase 1 and Phase 2, merged into **one project**, plus:

- **Zero-install running** — a Maven Wrapper (`mvnw` / `mvnw.cmd`) is
  checked in, so you do **not** need Maven installed at all. It
  downloads the right Maven version itself, the first time you run it.
- **Persistent by default** — the H2 database is now file-based
  (`./data/netsim.mv.db`), not in-memory, so topologies and run
  history survive an app restart with zero configuration.
- **Auto-rehydration** — on startup, every previously saved topology
  is reloaded from the database back into the live graph.
- **A built-in web dashboard** — open `http://localhost:8080/` in a
  browser and manage everything (create topologies, add routers/links,
  fault-inject, run simulations, watch live events) without writing a
  single `curl` command.
- **Auto-seeded demo** — the very first time you run it with an empty
  database, a small 4-router demo topology is created automatically
  and a simulation is run against it, with the results (and
  ready-to-paste `curl` commands) printed to the console.
- **Full CRUD** — delete routers, links, and whole topologies (Phase
  1/2 could only create and fault-inject).
- **Bulk import/export** — save a topology as JSON, or hand-write one
  and import it in one request.
- **Network-wide analysis** — one endpoint simulates every router pair
  and reports reachability + average latency, instead of running pairs
  one at a time.
- **Three routing algorithms** — Dijkstra, Bellman-Ford, and
  distance-vector.
- **Live WebSocket event stream**, **JPA persistence**, and
  **OpenAPI/Swagger docs**, carried over from Phase 2.

---

## 1. Prerequisites

You need a **Java 21 JDK**. That's it — Maven is not required, thanks
to the wrapper.

Check what you have:
```
java -version
```
If that fails or shows a version older than 21, install one:

| OS | Command |
|---|---|
| Arch Linux | `sudo pacman -S jdk21-openjdk` |
| Ubuntu/Debian | `sudo apt install openjdk-21-jdk` |
| Fedora | `sudo dnf install java-21-openjdk` |
| macOS (Homebrew) | `brew install openjdk@21` |
| Windows | Install [Eclipse Temurin 21](https://adoptium.net/) |

If you have multiple JDKs installed on Arch and `java -version` shows
the wrong one:
```
sudo archlinux-java set java-21-openjdk
```

You do **not** need to separately install `maven` — if you already
did (`sudo pacman -S maven`), that's fine too, it just won't be used
by the commands below since `./mvnw` bundles its own.

---

## 2. Run it

```
cd phase3-network-routing-simulator
./mvnw spring-boot:run
```

On Windows (Command Prompt or PowerShell), use `mvnw.cmd` instead:
```
cd phase3-network-routing-simulator
mvnw.cmd spring-boot:run
```

**What happens the first time:**
1. `./mvnw` downloads Maven itself (a few MB, one-time, needs internet).
2. Maven downloads all the project's dependencies (one-time, needs internet).
3. The app compiles and starts on port 8080.
4. Since the database is empty, a demo topology is seeded automatically
   and you'll see something like this printed to the console:

```
======================================================================
 Demo topology seeded: 'demo-network' (id: topo-a1b2c3)
 R1(R-11aa22) --5ms--> R2(R-33bb44) --2ms--> R4(R-55cc66)
 R1(R-11aa22) --1ms--> R3(R-77dd88) --1ms--> R4(R-55cc66)
 Demo simulation R1 -> R4 via dijkstra: DELIVERED, path=[...], latency=2.10ms
----------------------------------------------------------------------
 Open the dashboard:      http://localhost:8080/
 Or try the API directly:
   curl http://localhost:8080/api/topologies/topo-a1b2c3
   curl -X POST http://localhost:8080/api/simulations/run \
     -H 'Content-Type: application/json' \
     -d '{"topologyId":"topo-a1b2c3","sourceRouterId":"R-11aa22","destRouterId":"R-55cc66","algorithm":"dijkstra"}'
 API docs:                 http://localhost:8080/swagger-ui.html
======================================================================
```

Subsequent runs skip the seeding (your topology already exists in the
database) and start straight away.

---

## 3. Use it

**Easiest: open the dashboard.**
```
http://localhost:8080/
```
Create/select a topology on the left, add routers and links in the
middle, fault-inject by clicking the UP/DOWN pills, run a simulation,
and watch the live event log on the right update as the packet hops
through the network.

**Or use the API directly** — full interactive docs at:
```
http://localhost:8080/swagger-ui.html
```

**Or inspect the database directly** (H2 console):
```
http://localhost:8080/h2-console
```
JDBC URL: `jdbc:h2:file:./data/netsim`, user `sa`, empty password.

---

## 4. Common commands

```bash
# Run the app
./mvnw spring-boot:run

# Run the test suite
./mvnw test

# Build a standalone jar (target/network-routing-simulator-3.0.0.jar)
./mvnw package

# Run that jar directly (no Maven needed at all at this point)
java -jar target/network-routing-simulator-3.0.0.jar

# Start with a completely empty system (skip the demo seed)
./mvnw spring-boot:run -Dspring-boot.run.arguments=--app.demo.seed-enabled=false

# Use a different port
./mvnw spring-boot:run -Dspring-boot.run.arguments=--server.port=8081

# Reset all data (delete the local database file, then run again)
rm -rf data/
./mvnw spring-boot:run
```

---

## 5. Run with PostgreSQL instead of H2 (optional)

Only worth doing if you specifically want to test against Postgres.
Requires Docker:
```
docker compose up --build
```
This builds the app image and starts it alongside a Postgres 16
container (see `docker-compose.yml` / `Dockerfile`). Everything else
(dashboard, API, WebSocket) works exactly the same either way.

---

## 6. Troubleshooting

**`bash: mvn: command not found`**
You're trying to run `mvn` instead of `./mvnw`. Use the wrapper
script that's checked into this project — see section 2. (If you'd
still rather install Maven system-wide: `sudo pacman -S maven` on
Arch, `sudo apt install maven` on Ubuntu/Debian.)

**`./mvnw: Permission denied`**
```
chmod +x mvnw
./mvnw spring-boot:run
```

**Dependency download fails / times out**
`./mvnw` needs internet access on first run (to fetch Maven itself,
then the project dependencies from Maven Central). Check your network
connection and retry.

**`Port 8080 already in use`**
Something else is already using that port — stop it, or run this app
on a different one (see section 4).

**Arch mirror 404s during unrelated `pacman` installs**
Not related to this project, but if you hit it while installing a
JDK: `sudo pacman -Syyu` to force-refresh mirrors, then retry.

**I want to start over completely**
```
rm -rf data/ target/
./mvnw spring-boot:run
```

---

## 7. What's not implemented

Kafka event fan-out, MapStruct-generated mappers (hand-written
instead), authentication/multi-tenant workspaces, and horizontal
scaling — these remain open "Future Enhancements" from the original
design doc, same as in Phase 2.
